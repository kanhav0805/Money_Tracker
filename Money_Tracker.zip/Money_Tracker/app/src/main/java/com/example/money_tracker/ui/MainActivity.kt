package com.example.money_tracker.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.money_tracker.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}